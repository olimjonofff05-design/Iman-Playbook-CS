import { useState } from "react";

import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import BNPL from "./components/BNPL";
import Invest from "./components/Invest";

import "./Layout.css";

function App() {
  const [page, setPage] = useState("dashboard");

  function renderPage() {
    switch (page) {
      case "dashboard":
        return <Dashboard />;

      case "bnpl":
        return <BNPL />;

      case "invest":
        return <Invest />;

      case "merchant":
        return <h1>🏪 Merchant</h1>;

      case "faq":
        return <h1>📄 FAQ</h1>;

      case "scripts":
        return <h1>📞 Scripts</h1>;

      case "offer":
        return <h1>📑 Offer</h1>;

      case "settings":
        return <h1>⚙ Settings</h1>;

      default:
        return <Dashboard />;
    }
  }

  return (
    <div>
      <Header />

      <div className="layout">
        <Sidebar setPage={setPage} />

        <div className="content">
          {renderPage()}
        </div>
      </div>
    </div>
  );
}

export default App;