
import "./Sidebar.css";

function Sidebar() {
  return (
    <div className="sidebar">
      <h3>Menu</h3>

      <ul>
        <li>🏠 Dashboard</li>
        <li>🛒 BNPL</li>
        <li>💰 Invest</li>
        <li>🏪 Merchant</li>
        <li>📄 FAQ</li>
        <li>📞 Scripts</li>
        <li>📃 Offer</li>
        <li>⚙ Settings</li>
      </ul>
    </div>
  );
}

export default Sidebar;