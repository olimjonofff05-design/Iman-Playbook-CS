function Invest() {
  return (
    <div>
      <h1>Invest</h1>

      <p>Bu yerda Invest bo'limi bo'ladi.</p>
    </div>
  );
}

export default Invest;