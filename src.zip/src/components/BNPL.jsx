function BNPL() {
  return (
    <div>
      <h1>BNPL</h1>

      <p>Bu yerda BNPL Playbook bo'ladi.</p>
    </div>
  );
}

export default BNPL;